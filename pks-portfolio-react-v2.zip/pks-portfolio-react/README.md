# PKS.OS — Pankaj Kumar Sahu · FDE Software Engineer

A retro text-mode portfolio on top of a 3D ASCII world.
Built with **React 19**, **Tailwind CSS v4**, **Three.js** and **Vite**.

- The 3D scene is rendered into ASCII glyphs on the GPU.
- Every section has a 3D block-letter banner.
- An **ASCII spider** lowers itself on its thread down the right-hand rail as you scroll and catches one fly per section.
- Optional **8-bit sound effects** (synthesised live, no audio files) for scrolling, typing and UI.
- A real **terminal**, docked to the left or right edge, lets you navigate by typing.

---

## Quick start

```bash
npm install
npm run dev        # http://localhost:5173  (hot reload)
npm run build      # production build → dist/
npm run preview    # serve dist/ locally
```

You need Node.js 18 or newer.

---

## Where to edit things

| I want to change… | Edit |
|---|---|
| Name, role, tagline, about text, workflow, skills, projects, links | **`src/data/portfolio.js`** (all content lives here) |
| Contact form backend | `FORM_ENDPOINT` in `src/data/portfolio.js` |
| Colours, fonts, breakpoints | `@theme` block in `src/styles/index.css` |
| Theme variants (aurora / ember / glacier) | `:root` and `html[data-theme=…]` in `src/styles/index.css` |
| Layout or spacing of a section | Tailwind classes in `src/components/sections/*.jsx` |
| Terminal commands | `src/lib/terminalCommands.js` (one function per command) |
| Spider look (poses, fly/cocoon characters, leg speed) | constants at the top of `src/features/scroll-spider/spider.js` |
| Sound effects (volume, each sound's recipe, throttling) | `src/lib/sound.js` (`MASTER`, `FX`, `THROTTLE`) |
| 3D look per section | `sceneStates` in `src/features/three/scene.js` |

---

## Project structure

```
src/
├── main.jsx                     React entry
├── app/
│   ├── App.jsx                  composes the page, owns the engines (3D, scroll, terminal)
│   └── AppContext.js            shared state + actions
├── data/
│   └── portfolio.js             ← all editable content
├── styles/
│   └── index.css                Tailwind v4: @theme tokens, themes, retro component classes
├── components/
│   ├── layout/                  Nav (+ sound toggle), Footer, Boot, Cursor, CrtOverlay
│   ├── sections/                Hero, About, Skills, Projects, Contact
│   ├── terminal/                Terminal (docked dialog)
│   └── ui/                      Window, WindowBar, Section/Split, SectionHead, AsciiBanner, Stage3D, Lede
├── features/
│   ├── scroll-spider/           spider.js (pure logic) + ScrollSpider.jsx (rendering)
│   └── three/                   scene.js (WebGL + ASCII post-process, lazy-loaded)
├── hooks/                       useReveal, useReducedMotion, useSound
├── lib/                         ascii font, sound synth, scroll engine, scroll→3D bridge, store, terminal commands
└── dev/                         debugApi (window.PKS, used by tools/critic.py)
tools/
└── critic.py                    automated UI / smoothness / performance critic
```

### Styling approach
Layout, spacing, colour and typography are **Tailwind utilities in the JSX**.
The palette is closed: `--color-*: initial` removes Tailwind's default colours, so only the portfolio palette exists (`bg-ink-0`, `text-fg-2`, `border-primary` …), and no green utility can be generated.
A small `@layer components` block keeps the retro chrome that utilities can't express cleanly: double-rule window title bars, ASCII banners, corner-bracket stages, CRT overlays and reveal effects.

A few plain class names (`nav`, `sec-head`, `project`, `terminal`, `rail`, `spider` …) stay as stable hooks for the scroll engine and the critic. They carry little or no styling.

---

## The scroll spider

```
  ┬        ← anchor
  ¦
  @        ← a fly it already caught, wrapped in silk
  ¦
\(oo)/     ← the spider (legs switch pose every few pixels)
/(  )\
  ж        ← next fly: the start of the next section
```

- It hangs in a narrow rail on the right edge. Page content is padded so the rail never covers it.
- Scrolling lowers the spider. Each section start is a fly: reaching it wraps the fly into a cocoon, and scrolling back up releases it.
- The spider sways slightly, and the next fly buzzes (both stop under reduced motion).
- Click anywhere on the rail to jump there.
- It's an ARIA `progressbar` ("2 of 4 sections reached").

## Sound

All effects are synthesised in the browser with the Web Audio API (square, triangle and saw waves plus filtered noise), so there's nothing to download.

| Event | Sound |
|---|---|
| Scrolling | soft tick on every spider step, rising in pitch down the page |
| Spider catches / releases a fly | rising / falling 4-note arpeggio |
| Typing in the terminal | randomised keyboard clack; Backspace and Enter have their own |
| Unknown command, form error | low double buzz |
| Navigation | pitch sweep "warp" |
| Terminal open / close | CRT power-on sweep / power-off drop |
| Hover / click | tiny blips |
| Theme / dock change, boot | chords and chirps |

- **Off by default.** Turn it on with the **[♪ OFF]** header button or `sound on` in the terminal; the choice is remembered.
- No audio context is created until you opt in, and audio pauses while the tab is hidden.
- Each effect is throttled, and the number of simultaneous voices is capped, so fast scrolling or typing never turns into noise.
- `sound test` plays a short demo.

## The terminal

- Opens with `/`, `` ` ``, **[ ENTER TERMINAL ]** or the header **>_** button.
- Docked to the right (next to the spider rail) by default and 380px wide.
- Move it with **[⇄]** or `dock left` / `dock right`. The choice is remembered.
- On phones it becomes a bottom sheet.

Commands: `help` `about` `skills` `projects` `contact` `home` `open <section>` `cd <section>` `whoami` `ls` `pwd` `cat about.txt|skills.txt|projects.txt` `banner <text>` `render ascii|vector` `theme aurora|ember|glacier` `dock left|right` `sound on|off|test` `history` `clear` `exit`

Easter eggs: `coffee` `matrix` `neofetch` `sudo hire pankaj`

Commands come only from a fixed map. There is no `eval`, and output is rendered as text.

---

## Critic

```bash
pip install playwright pillow numpy && playwright install chromium
npm run build && npx vite preview --port 8000
python tools/critic.py --url http://localhost:8000/ --shots critic-shots
```

It scores UI & layout, readability (WCAG contrast against real pixels), smoothness, performance, accessibility, retro identity and sound, each out of 10, at 320–1920px.
It also checks the spider (fits its rail, never covers content, descends and catches one fly per section), the terminal (docked, ≤ 400px wide, never over the rail, dock toggle works, full-width sheet on phones) and sound (off and silent until opted in, every effect fires, typing bursts are throttled, mute really mutes).

---

## Deploy

`npm run build` creates `dist/`, a static site. Upload it to Netlify, Vercel, GitHub Pages or Cloudflare Pages.
`base: './'` in `vite.config.js` makes it work from a sub-path too.

## Accessibility
- `prefers-reduced-motion`: no boot screen, no render loop, no smooth scrolling, tilt or reveals.
- Semantic landmarks and a skip link.
- Every banner is `aria-hidden` and has a real heading.
- The terminal is a labelled dialog: Escape closes it and focus returns to the button that opened it.
- Focus is visible everywhere.
