/* ==========================================================================
   portfolio.js — ALL editable content lives here.

   Change text, skills, projects and links in this file; the UI, the
   terminal (`whoami`, `cat skills.txt`, `projects` …) and the 3D scene all
   read from it. No other file needs to change for normal content edits.
   ========================================================================== */

export const PROFILE = {
  name: 'Pankaj Kumar Sahu',
  // Big 3D ASCII banners in the hero.
  // Supported characters: A–Z, 0–9, space, . - _
  bannerLine1: 'PANKAJ',
  bannerLine2: 'KUMAR SAHU',
  role: 'FDE Software Engineer',
  roleTag: 'FDE',
  roleLine: 'SOFTWARE ENGINEER',
  location: 'India',
  node: 'PKS-01',
  tagline: ['Building software where engineering,', 'systems and real-world problems meet.'],
};

/* Optional links — leave '' to hide a link. */
export const LINKS = {
  email: '',     // 'you@example.com'
  github: '',    // 'https://github.com/your-handle'
  linkedin: '',  // 'https://www.linkedin.com/in/your-handle'
  resume: '',    // '/resume.pdf'  (put the file in /public)
};

/* Contact form endpoint.
   '' = DEMO MODE: input is validated, nothing is sent, and the UI says so.
   Use a Formspree URL (https://formspree.io/f/xxxx) or any API that accepts
   a JSON POST { name, email, message } and returns 2xx. */
export const FORM_ENDPOINT = '';

/* Section headings: banner = 3D ASCII block letters (same character set as above). */
export const SECTIONS = {
  about: { kicker: '// 01 ─ ABOUT', banner: 'ABOUT', title: '> from ambiguity to working systems' },
  skills: { kicker: '// 02 ─ SYSTEM_CAPABILITIES', banner: 'STACK', title: '> tools in the system' },
  projects: { kicker: '// 03 ─ PROJECT_ARCHIVE', banner: 'PROJECTS', title: '> stored builds' },
  contact: { kicker: '// 04 ─ ESTABLISH_CONNECTION', banner: 'CONTACT', title: ["LET'S BUILD", 'SOMETHING USEFUL.'] },
};

export const ABOUT = [
  `${PROFILE.name} is an FDE Software Engineer focused on turning ambiguous real-world requirements into reliable software systems.`,
  'Working close to the people who will actually use the software, he clarifies what the problem really is, designs a system that fits it, and carries the work through to something deployed, observable and maintainable.',
];

export const WORKFLOW = [
  { title: 'DISCOVER', text: 'Understand the people, the constraints and what "done" really means.' },
  { title: 'ARCHITECT', text: 'Shape data models, interfaces and boundaries that can evolve.' },
  { title: 'BUILD', text: 'Typed, readable code delivered in small reviewable increments.' },
  { title: 'VALIDATE', text: 'Tests, evaluation and real feedback before anything is called finished.' },
  { title: 'DEPLOY', text: 'Ship, observe in production and iterate.' },
];

/* Skill groups. `key` links a card to its node in the 3D graph — keep these six keys.
   `status` is optional and null by default. Set 'ACTIVE' | 'EXPERIENCED' | 'EXPLORING'
   only where it is honestly true. No percentages are shown anywhere. */
export const SKILLS = [
  { key: 'languages', title: 'LANGUAGES', items: [{ name: 'Python', status: null }, { name: 'JavaScript', status: null }, { name: 'TypeScript', status: null }, { name: 'SQL', status: null }] },
  { key: 'backend', title: 'BACKEND', items: [{ name: 'FastAPI', status: null }, { name: 'Node.js', status: null }, { name: 'REST APIs', status: null }, { name: 'SQLAlchemy', status: null }] },
  { key: 'ai', title: 'AI / ML', items: [{ name: 'TensorFlow', status: null }, { name: 'Keras', status: null }, { name: 'scikit-learn', status: null }, { name: 'Computer Vision', status: null }] },
  { key: 'frontend', title: 'FRONTEND', items: [{ name: 'HTML', status: null }, { name: 'CSS', status: null }, { name: 'JavaScript', status: null }, { name: 'Three.js', status: null }, { name: 'WebGL', status: null }] },
  { key: 'data', title: 'DATA', items: [{ name: 'PostgreSQL', status: null }, { name: 'SQLite', status: null }, { name: 'Pandas', status: null }, { name: 'NumPy', status: null }] },
  { key: 'tools', title: 'TOOLS', items: [{ name: 'Git', status: null }, { name: 'Docker', status: null }, { name: 'CI/CD', status: null }] },
];

/* Projects. color = accent (also drives the 3D lighting while the card is active).
   Add repo / demo URLs when they exist — empty links are hidden. */
export const PROJECTS = [
  {
    title: 'RETAILMIND', dir: 'retailmind', color: 'var(--violet)', textColor: 'var(--violet-soft)',
    desc: 'End-to-end machine learning workflow for retail intelligence, from data preparation and evaluation to explainable model outputs.',
    tech: ['Python', 'TensorFlow', 'FastAPI'],
    flowLabel: 'PIPELINE', flow: ['ingest', 'prepare', 'train', 'evaluate', 'explain'],
    details: ['Data preparation as a repeatable pipeline stage', 'Model evaluation before anything is served', 'Explainable outputs alongside predictions', 'Model exposed through a FastAPI service'],
    links: { repo: '', demo: '' },
  },
  {
    title: 'CNN VISUALIZER', dir: 'cnn-visualizer', color: 'var(--cyan)', textColor: 'var(--cyan)',
    desc: 'Interactive 3D experience for understanding convolutional neural networks, feature maps and backpropagation.',
    tech: ['Three.js', 'WebGL', 'CNN'],
    flowLabel: 'LAYER STACK', flow: ['input', 'conv', 'pool', 'dense', 'softmax'],
    details: ['Layers and feature maps rendered as a navigable 3D scene', 'Visual walk-through of the backward pass', 'Runs entirely in the browser with WebGL'],
    links: { repo: '', demo: '' },
  },
  {
    title: 'TASKFLOW API', dir: 'taskflow-api', color: 'var(--coral)', textColor: 'var(--coral)',
    desc: 'Typed task-management API using validation, relational persistence, clean CRUD architecture and testable services.',
    tech: ['FastAPI', 'SQLAlchemy', 'Pydantic'],
    flowLabel: 'REQUEST PATH', flow: ['route', 'validate', 'service', 'ORM', 'database'],
    details: ['Pydantic schemas validate every request and response', 'SQLAlchemy models for relational persistence', 'CRUD logic kept in a testable service layer'],
    links: { repo: '', demo: '' },
  },
];

export const THEMES = ['aurora', 'ember', 'glacier'];
export const SECTION_ORDER = ['home', 'about', 'skills', 'projects', 'contact'];

