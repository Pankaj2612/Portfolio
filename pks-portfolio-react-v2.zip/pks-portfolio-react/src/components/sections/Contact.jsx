/* CONTACT — terminal-style form with validation and an honest DEMO MODE. */
import { useRef, useState } from 'react';
import SectionHead from '../ui/SectionHead.jsx';
import Window from '../ui/Window.jsx';
import Lede from '../ui/Lede.jsx';
import { Section, Split } from '../ui/Section.jsx';
import { FORM_ENDPOINT, LINKS } from '../../data/portfolio.js';
import { sfx } from '../../lib/sound.js';

const RULES = {
  name: v => (v.trim().length < 2 ? 'name: at least 2 characters required' : ''),
  email: v => (/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.trim()) ? '' : 'email: enter a valid address'),
  message: v => (v.trim().length < 10 ? 'message: at least 10 characters required' : ''),
};
const FIELDS = [
  { key: 'name', id: 'fName', type: 'text', autoComplete: 'name', max: 80 },
  { key: 'email', id: 'fEmail', type: 'email', autoComplete: 'email', max: 120 },
  { key: 'message', id: 'fMsg', textarea: true, max: 4000 },
];
const STATUS = {
  demo: 'border border-dashed border-highlight bg-coral/5 px-3 py-2.5 text-coral-soft',
  ok: 'border border-secondary px-3 py-2.5 text-cyan',
  err: 'text-highlight',
  '': 'text-fg-2',
};

function ContactLinks() {
  const items = [
    LINKS.email && ['email', `mailto:${LINKS.email}`, LINKS.email],
    LINKS.github && ['github', LINKS.github, 'GitHub'],
    LINKS.linkedin && ['linkedin', LINKS.linkedin, 'LinkedIn'],
    LINKS.resume && ['resume', LINKS.resume, 'Résumé'],
  ].filter(Boolean);
  if (!items.length) return null;
  return (
    <ul className="mb-[22px] mt-0 flex list-none flex-wrap gap-2.5 p-0 text-[13px]" aria-label="Contact links">
      {items.map(([k, href, label]) => {
        const ext = !href.startsWith('mailto:');
        return (
          <li key={k}>
            <a href={href} aria-label={`${k}: ${label}`} {...(ext ? { target: '_blank', rel: 'noopener noreferrer' } : {})} className="inline-block border border-line-strong bg-ink-1 px-2.5 py-1.5 hover:bg-highlight hover:text-ink-0">
              &gt; {label}
            </a>
          </li>
        );
      })}
    </ul>
  );
}

export default function Contact() {
  const [values, setValues] = useState({ name: '', email: '', message: '' });
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState(null);
  const [sending, setSending] = useState(false);
  const refs = { name: useRef(null), email: useRef(null), message: useRef(null) };

  const check = (key, v = values[key]) => { const msg = RULES[key](v); setErrors(e => ({ ...e, [key]: msg })); return !msg; };
  const onChange = key => (e) => { const v = e.target.value; setValues(s => ({ ...s, [key]: v })); if (errors[key]) check(key, v); };

  async function onSubmit(e) {
    e.preventDefault();
    const next = Object.fromEntries(Object.keys(RULES).map(k => [k, RULES[k](values[k])]));
    setErrors(next);
    const firstBad = Object.keys(next).find(k => next[k]);
    if (firstBad) { setStatus({ kind: 'err', text: '✕ validation failed — fix the highlighted fields.' }); sfx.play('error'); refs[firstBad].current?.focus(); return; }
    if (!FORM_ENDPOINT) {
      sfx.play('success');
      setStatus({ kind: 'demo', text: 'DEMO MODE — input is valid, but NO message was sent. Set FORM_ENDPOINT in src/data/portfolio.js (your backend, Formspree or EmailJS) to transmit messages.' });
      return;
    }
    setSending(true);
    setStatus({ kind: '', text: 'opening connection…' });
    try {
      const res = await fetch(FORM_ENDPOINT, { method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'application/json' }, body: JSON.stringify({ name: values.name.trim(), email: values.email.trim(), message: values.message.trim() }) });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      setStatus({ kind: 'ok', text: '✓ message delivered to the endpoint. Thank you — I will get back to you.' });
      setValues({ name: '', email: '', message: '' });
    } catch (err) {
      setStatus({ kind: 'err', text: `✕ transmission failed (${err.message}). Nothing was delivered — please try again later.` });
    } finally { setSending(false); }
  }

  return (
    <Section id="contact" labelledBy="contactTitle" className="lg:min-h-screen">
      <SectionHead section="contact" titleId="contactTitle" big />
      <Split side="right" stage={{ id: 'contact', topLeft: 'PORTAL.LINK', bottomRight: 'STATUS: LISTENING' }}>
        <Lede>Share a problem, a role or an idea. A clear description of what you're trying to achieve is the best place to start.</Lede>
        <ContactLinks />
        <Window title="~/connect.sh" meta={FORM_ENDPOINT ? 'LIVE' : 'DEMO'} metaClass={FORM_ENDPOINT ? 'text-secondary' : 'text-highlight'} reveal="crt">
          <form className="grid gap-1" noValidate onSubmit={onSubmit}>
            {FIELDS.map((f) => {
              const errId = `${f.id}Err`;
              const bad = !!errors[f.key];
              const common = {
                id: f.id, name: f.key, ref: refs[f.key], value: values[f.key], required: true, maxLength: f.max,
                onChange: onChange(f.key), onBlur: () => values[f.key] && check(f.key),
                'aria-invalid': bad ? 'true' : 'false', 'aria-describedby': errId,
                className: `w-full rounded-none border bg-ink-0 px-3 py-2.5 font-mono text-sm text-fg caret-highlight outline-none transition-[border-color,box-shadow] focus:border-secondary focus:shadow-[4px_4px_0_rgba(103,232,249,.25)] ${bad ? 'border-highlight' : 'border-line-strong'}`,
              };
              return (
                <div key={f.key}>
                  <label htmlFor={f.id} className="mb-1 block text-[13px] tracking-[.08em] text-secondary">&gt; {f.key}</label>
                  {f.textarea ? <textarea rows={5} {...common} className={`${common.className} min-h-[120px] resize-y`} /> : <input type={f.type} autoComplete={f.autoComplete} {...common} />}
                  <span id={errId} className="mt-0.5 block min-h-[1.4em] text-xs text-highlight">{bad ? `✕ ${errors[f.key]}` : ''}</span>
                </div>
              );
            })}
            <button type="submit" className="btn btn-primary mt-1.5 justify-self-start" disabled={sending}>{sending ? '[ TRANSMITTING… ]' : '[ EXECUTE_SEND ]'}</button>
            <p role="status" aria-live="polite" className={`mb-0 mt-3.5 text-[13px] leading-[1.55] empty:hidden ${STATUS[status?.kind || '']}`}>{status?.text || ''}</p>
          </form>
        </Window>
      </Split>
    </Section>
  );
}

